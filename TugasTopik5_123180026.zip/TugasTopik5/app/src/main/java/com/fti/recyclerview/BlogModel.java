package com.fti.recyclerview;

public class BlogModel {
    private String nameBlog;
    private String directorBlog;
    private int imageBlog;
    private String descBlog;

    public String getDescBlog() {
        return descBlog;
    }

    public void setDescBlog(String descBlog) {
        this.descBlog = descBlog;
    }

    public String getDirectorBlog() {
        return directorBlog;
    }

    public void setDirectorBlog(String directorBlog) {
        this.directorBlog = directorBlog;
    }

    public String getNameBlog() {
        return nameBlog;
    }

    public void setNameBlog(String nameBlog) {
        this.nameBlog = nameBlog;
    }

    public int getImageBlog() {
        return imageBlog;
    }

    public void setImageBlog(int imageBlog) {
        this.imageBlog = imageBlog;
    }

}
