package com.fti.recyclerview;

import java.util.ArrayList;

public class BlogData {
    private static String[] title = new String[]{"BukaLapak", "Facebook", "Gojek", "Grab", "Instagram", "Lazada", "Line", "Shoope", "Telegram", "TokoPedia"};
    private static int[] image = new int[]{R.drawable.bukalapak, R.drawable.facebook1, R.drawable.gojek1, R.drawable.grab, R.drawable.instagrm1, R.drawable.lazada, R.drawable.line, R.drawable.shopee, R.drawable.telegram, R.drawable.tokopedia};
    private static String[] director = new String[]{".....","....",".....","....",".....","......","....","...."," ....", "....."};

    private static String[] desc = new String[]{
            "Bukalapak merupakan salah satu perusahaan e-commerce di Indonesia. Didirikan oleh Achmad Zaky, Nugroho Herucahyono, dan Muhamad Fajrin Rasyid pada tahun 2010, Bukalapak awalnya merupakan toko daring yang memungkinkan para pelaku Usaha Kecil dan Menengah (UKM) untuk merambah ke dunia maya.[2] Perusahaan tersebut kini telah melakukan ekspansi ke berbagai lini bisnis lain, termasuk membantu meningkatkan penjualan para warung tradisional lewat layanan Mitra Bukalapak.[3] Pada tahun 2017, Bukalapak menjadi salah satu startup unikorn asal tanah air.",
            "Facebook, Inc. adalah sebuah layanan jejaring sosial berkantor pusat di Menlo Park, California, Amerika Serikat yang diluncurkan pada bulan Februari 2004. Per September 2012, Facebook memiliki lebih dari satu miliar pengguna aktif,[11] lebih dari separuhnya menggunakan telepon genggam.[12] Pengguna harus mendaftar sebelum dapat menggunakan situs ini",
            "Gojek (sebelumnya ditulis GO-JEK) merupakan sebuah perusahaan teknologi asal Indonesia yang melayani angkutan melalui jasa ojek. Perusahaan ini didirikan pada tahun 2010 di Jakarta oleh Nadiem Makarim.[3][4] Saat ini, Gojek telah tersedia di 50 kota di Indonesia.[1] Hingga bulan Juni 2016, aplikasi Gojek sudah diunduh sebanyak hampir 10 juta kali di Google Play pada sistem operasi Android,[5] dan telah tersedia di App Store. Gojek juga mempunyai layanan pembayaran digital yang bernama Gopay. Selain di Indonesia, layanan Gojek kini telah tersedia di Thailand, Vietnam dan Singapura.",
            "Grab merupakan salah satu platform layanan on demand yang bermarkas di Singapura. Berawal dari layanan transportasi, perusahaan tersebut kini telah mempunyai layanan lain seperti pengantaran makanan dan pembayaran yang bisa diakses lewat aplikasi mobile.",
            "Instagram adalah sebuah aplikasi berbagi foto dan video yang memungkinkan pengguna mengambil foto, mengambil video, menerapkan filter digital, dan membagikannya ke berbagai layanan jejaring sosial, termasuk milik Instagram sendiri",
            "Lazada merupakan perusahaan yang bergerak di bidang layanan jual beli online dan ritel e-commerce, hasil pengembangan dari perusahaan inkubator teknologi internet asal Jerman yaitu Rocket Internet. Roket internet juga telah sukses menciptakan berbagai perusahan-perusahaan yang inovatif dan kreatif di berbagai belahan dunia, yang berkantor pusat di Berlin, Jerman. Proyek yang dimiliki Rocket Internet lainya di Indonesia antara lain zalora, foodpanda, traveloka.",
            "LINE adalah sebuah aplikasi pengirim pesan instan gratis yang dapat digunakan pada berbagai platform seperti telepon cerdas, tablet, dan komputer. LINE difungsikan dengan menggunakan jaringan internet sehingga pengguna LINE dapat melakukan aktivitas seperti mengirim pesan teks, mengirim gambar, video, pesan suara, dan lain lain. LINE diklaim sebagai aplikasi pengirim pesan instan terlaris di 42 negara.",
            "Shopee merupakan sebuah platform yang dirancang khusus untuk menyuguhkan pengalaman berbelanja online yang mudah, aman dan cepat dengan sistem pembayaran dan dukungan logistik yang kuat. Shopee memiliki tujuan untuk terus berkembang menjadi e-commerce pilihan utama di Indonesia.",
            "Telegram adalah sebuah aplikasi layanan pengirim pesan instan multiplatform berbasis awan yang bersifat gratis dan nirlaba.[10][11] Klien Telegram tersedia untuk perangkat telepon seluler (Android, iOS, Windows Phone, Ubuntu Touch) dan sistem perangkat komputer (Windows, OS X, Linux).[12] Para pengguna dapat mengirim pesan dan bertukar foto, video, stiker, audio, dan tipe berkas lainnya. Telegram juga menyediakan pengiriman pesan enkripsi ujung-ke-ujung opsional.",
            "Tokopedia merupakan perusahaan perdagangan elektronik atau sering disebut toko daring. Sejak didirikan pada tahun 2009, Tokopedia telah bertransformasi menjadi sebuah unicorn yang berpengaruh tidak hanya di Indonesia tetapi juga di Asia Tenggara.[3] Hingga saat ini, Tokopedia termasuk marketplace yang paling banyak dikunjungi oleh masyarakat Indonesia."
    };

    public static ArrayList<BlogModel> getListData(){
        BlogModel blogModel = null;
        ArrayList<BlogModel> list = new ArrayList<>();
        for(int i = 0; i < title.length; i++){
            blogModel = new BlogModel();
            blogModel.setImageBlog(image[i]);
            blogModel.setNameBlog(title[i]);
            blogModel.setDirectorBlog(director[i]);
            blogModel.setDescBlog(desc[i]);
            list.add(blogModel);
        }
        return list;
    }
}
