package com.fti.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    private TextView blogNameBlog,blogDesc, blogDirector;
    private ImageView ivCoverBlog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ivCoverBlog = findViewById(R.id.ivCoverBlog);
        blogNameBlog = findViewById(R.id.blogNameBlog);
        blogDirector = findViewById(R.id.blogDirectorBlog);
        blogDesc = findViewById(R.id.blogDescBlog);

        int iCover = getIntent().getIntExtra("imageBlog",0);
        String sName = getIntent().getStringExtra("nameBlog");
        String sDirector= "" + getIntent().getStringExtra("directorBlog");
        String sDesc = getIntent().getStringExtra("descBlog");

        Glide.with(this).load(iCover).into(ivCoverBlog);
        blogNameBlog.setText(sName);
        blogDesc.setText(sDesc);
        blogDirector.setText(sDirector);

    }
}