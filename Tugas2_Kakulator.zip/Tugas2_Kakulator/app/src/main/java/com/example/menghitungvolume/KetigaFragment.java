package com.example.menghitungvolume;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class KetigaFragment extends Fragment {
    private Button btnHasil;
    private EditText txt_jari_jari, txt_tinggi;
    private TextView hasil;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_ketiga, container, false);
        btnHasil = v.findViewById(R.id.btnHasil);
        txt_jari_jari = v.findViewById(R.id.txt_jari_jari);
        txt_tinggi = v.findViewById(R.id.txt_tinggi);
        hasil = v.findViewById(R.id.hasil);

        btnHasil.setOnClickListener(new View.OnClickListener(){
            @SuppressLint("DefaultLocale")
            public void onClick(View v){
                String nilai1 = txt_jari_jari.getText().toString();
                String nilai2 = txt_tinggi.getText().toString();

                if(nilai1.isEmpty()){
                    txt_jari_jari.setError("Data Tidak Boleh Kosong");
                    txt_jari_jari.requestFocus();
                } else if(nilai2.isEmpty()){
                    txt_tinggi.setError("Data Tidak Boleh Kosong");
                    txt_tinggi.requestFocus();
                } else {
                    Double jari = Double.parseDouble(nilai1);
                    Double tinggi = Double.parseDouble(nilai2);

                    Double volume = 3.14 * jari * jari * tinggi;
                    hasil.setText(String.format("%.2f", volume));
                }
            }
        });


        return v;
    }
}