package com.example.menghitungvolume;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class PertamaFragment extends Fragment {
    private Button btnHasil;
    private EditText txt_sisi;
    private TextView hasil;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_pertama, container, false);
        btnHasil = v.findViewById(R.id.btnHasil);
        txt_sisi = v.findViewById(R.id.txt_sisi);
        hasil = v.findViewById(R.id.hasil);

        btnHasil.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String nilai1 = txt_sisi.getText().toString();

                if(nilai1.isEmpty()){
                    txt_sisi.setError("Data Tidak Boleh Kosong");
                    txt_sisi.requestFocus();
                } else {
                    Integer sisi = Integer.parseInt(nilai1);

                    Integer volume = sisi * sisi * sisi;
                    hasil.setText(String.valueOf(volume));
                }
            }
        });

        return v;
    }
}
